#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
	int a,b;
	cout<<"ingrese un numero entero para a: ";
	cin>>a;
	cout<<"ingrese un numero entero para b: ";
	cin>>b;
	if(a%b==0)
		cout<<a<<" si es divisible por "<<b<<endl;
	else
		cout<<a<<" no es divisible por "<<b<<endl;
	return 0;
}

