#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
	int i,cp=0,ci=0,pro,suma=0,x,n,su=0;
	do {
		cout<<"la cantidad de numeros a ingresar: ";
		cin>>n;
	} while(n<=0);
	for (i=2; i<=n;i=i+2){
		suma=suma+i;
	}
	cout<<"las suma es: "<<suma<<endl;
	for (i=1; i<=n; i++){
		cout<<"ingrese numero: ";
		cin>>x;
		if(x%2==0)
			cp=cp+1;
		else
			ci=ci+1;
	}
	cout<<"la cantidad de numeros pares es: "<<cp<<endl;
	for (i=1; i<=n; i+=2){
		su=su+i;
		pro=su/ci;
	}
	cout<<"el promedio de los numeros impares es: "<<pro<<endl;

	return 0;
}

