#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
	int i,suma=0;
	for (i=1;i<=100;i++){
		suma=suma+i;
	}
	cout<<"la suma del 1 al 100 es: "<<suma<<endl;
	return 0;
}

